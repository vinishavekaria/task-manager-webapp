from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render
from .models import Task, User, PriorityAssignment
import json
from datetime import datetime

def home(request):
    context = {'checked': True}
    return render(request, 'home.html', context)


@csrf_exempt
def get_tasks(request):
    """
    GET requests to fetch all tasks and their users with priority
    Returns a JSON response with the list of tasks with dettails
    """
    if request.method == 'GET':
        tasks = Task.objects.all()
        response_data = []
        
        for task in tasks:
            task_data = {
                'id': task.id,
                'title': task.title,
                'description': task.description,
                'due_date': task.due_date.strftime('%Y-%m-%d'), 
                'completed': task.completed,
                'users': []
            }

            for assignment in task.priorityassignment_set.all():
                task_data['users'].append({
                    'username': assignment.user.username,
                    'priority': assignment.priority_level
                })
            
            response_data.append(task_data)
        
        return JsonResponse(response_data, safe=False)

@csrf_exempt
def add_task(request):
    """
    POST requests to create a new task. Takes input and saves the task
    """
    if request.method == 'POST':
        try:
            data = json.loads(request.body)

            # Validate  fields
            title = data.get('title')
            description = data.get('description')
            due_date = data.get('due_date')
            completed = data.get('completed', False)

            if not title or not description:
                return JsonResponse({'error': 'Title and description are required'}, status=400)

            if not due_date:
                return JsonResponse({'error': 'Due date is required'}, status=400)

            try:
                due_date = datetime.strptime(due_date, '%Y-%m-%d').date()
            except ValueError:
                return JsonResponse({'error': 'Invalid due date format, expected YYYY-MM-DD'}, status=400)

            # Create the new task
            task = Task.objects.create(
                title=title,
                description=description,
                due_date=due_date,
                completed=completed
            )

            users = data.get('users', [])
            for user_data in users:
                try:
                    user = User.objects.get(id=user_data['user_id'])
                    PriorityAssignment.objects.create(
                        task=task,
                        user=user,
                        priority_level=user_data['priority']
                    )
                except User.DoesNotExist:
                    continue  

            return JsonResponse({
                'status': 'success',
                'id': task.id,
                'title': task.title,
                'description': task.description,
                'due_date': task.due_date.strftime('%Y-%m-%d'),
                'completed': task.completed
            })

        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON format'}, status=400)
        except Exception as e:
            print(f"Error adding task: {str(e)}")
            return JsonResponse({'error': str(e)}, status=500)



@csrf_exempt
def update_task(request, task_id):
    """
    PUT requests to update an existing task and updates the priority assignments.
    """
    if request.method == 'PUT':
        try:
            data = json.loads(request.body)
            task = Task.objects.get(id=task_id)

            task.title = data.get('title', task.title)
            task.description = data.get('description', task.description)
            
            due_date = data.get('due_date')
            if due_date:
                try:
                    # Convert the due_date string
                    task.due_date = datetime.strptime(due_date, '%Y-%m-%d').date()
                except ValueError:
                    return JsonResponse({'error': 'Invalid due date format, expected YYYY-MM-DD'}, status=400)
            task.completed = data.get('completed', task.completed)
            task.save()

            if 'users' in data:
                for user_data in data['users']:
                    assignment, created = PriorityAssignment.objects.get_or_create(
                        task=task,
                        user_id=user_data['user_id']
                    )
                    assignment.priority_level = user_data['priority']
                    assignment.save()

            return JsonResponse({
                'status': 'success',
                'id': task.id,
                'title': task.title,
                'description': task.description,
                'due_date': task.due_date.strftime('%Y-%m-%d'),
                'completed': task.completed
            })

        except Task.DoesNotExist:
            return JsonResponse({'error': 'Task not found'}, status=404)
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON format'}, status=400)
        except Exception as e:
            print(f"Error updating task {task_id}: {str(e)}")
            return JsonResponse({'error': str(e)}, status=500)


@csrf_exempt
def delete_task(request, task_id):
    """
    DELETE requests to delte a current task from the database
    """
    if request.method == 'DELETE':
        try:
            task = Task.objects.get(id=task_id)
            task.delete()
            return JsonResponse({'status': 'success'})
        except Task.DoesNotExist:
            return JsonResponse({'error': 'Task not found'}, status=404)
        except Exception as e:
            print(f"Error deleting task {task_id}: {str(e)}")
            return JsonResponse({'error': str(e)}, status=500)
        
def get_users(request):
    """
    Handles GET requests to retrieve the list of all users.
    """
    users = User.objects.all()  # Retrieve all users
    user_list = [{"id": user.id, "username": user.username, "email": user.email} for user in users]
    return JsonResponse(user_list, safe=False)

def add_user(request):
    """
    Handles POST requests to create a new user.
    """
    if request.method == 'POST':
        try:
            data = json.loads(request.body)

            # Extract user data from request
            username = data.get('username')
            email = data.get('email')

            if not username or not email:
                return JsonResponse({'error': 'Username and email are required'}, status=400)

            # Create new user
            user = User.objects.create(
                username=username,
                email=email,
            )

            # Respond with the newly created user data
            return JsonResponse({
                'id': user.id,
                'username': user.username,
                'email': user.email
            }, status=201)

        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON format'}, status=400)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)

def get_priority_assignments(request):
    priority_assignments = PriorityAssignment.objects.all().values('id', 'task', 'user', 'priority_level', 'assigned_date')
    return JsonResponse(list(priority_assignments), safe=False)

def assign_user_to_task(request, task_id):
    if request.method == 'POST':
        try:
            task = Task.objects.get(id=task_id)
            user_id = request.data.get('user_id')  # Extract the user ID from the request data
            user = User.objects.get(id=user_id)  # Get the user by ID
            
            # Add the user to the task (assumed that task has a ManyToMany relationship with User)
            task.users.add(user)
            task.save()
            
            return JsonResponse({'message': 'User assigned to task successfully'}, status=200)
        except Task.DoesNotExist:
            return JsonResponse({'error': 'Task not found'}, status=404)
        except User.DoesNotExist:
            return JsonResponse({'error': 'User not found'}, status=404)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)