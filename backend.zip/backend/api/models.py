from django.db import models

class User(models.Model):
    """
    Model representing a user in the system. Each user has a unique username and an email address.
    """
    username = models.CharField(max_length=150)
    email = models.EmailField()

    def __str__(self):
        return self.username

class Task(models.Model):
    """
    Each task has a title, description, due date, and completion status.
    It can also be assigned to multiple users through the PriorityAssignment model
    """
    title = models.CharField(max_length=255)
    description = models.TextField()
    due_date = models.DateField()
    completed = models.BooleanField(default=False)
    users = models.ManyToManyField(User, through='PriorityAssignment')

    def __str__(self):
        return self.title

class PriorityAssignment(models.Model):
    """
    many-to-many relationship between Task and User
    shows the priority of the task assigned to a user
    """
    task = models.ForeignKey(Task, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    priority_level = models.IntegerField()
    assigned_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"Task: {self.task.title} assigned to {self.user.username} with priority {self.priority_level}"