<template>
  <div class="user-form">
    <h3>Add New User</h3>
    <form @submit.prevent="submitForm">
      <div class="form-group">
        <label for="username">Username</label>
        <input v-model="newUser.username" id="username" type="text" class="form-control" required />
      </div>
      <div class="form-group">
        <label for="email">Email</label>
        <input v-model="newUser.email" id="email" type="email" class="form-control" required />
      </div>
      <button type="submit" class="btn btn-primary">Add User</button>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      newUser: {
        username: '',
        email: '',
      }
    };
  },
  methods: {
    // Method to submit the form and create a new user
    async submitForm() {
      try {
        const response = await fetch('http://localhost:8000/api/users/add/', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(this.newUser),
        });
        
        if (response.ok) {
          const data = await response.json();
          // Emit an event to notify the parent component that a new user has been added
          this.$emit('user-added', data);
          // Clear form after successful submission
          this.newUser.username = '';
          this.newUser.email = '';
        } else {
          console.error('Error adding user');
        }
      } catch (error) {
        console.error('Network error:', error);
      }
    }
  }
};
</script>

<style scoped>
.user-form {
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 8px;
}
</style>
