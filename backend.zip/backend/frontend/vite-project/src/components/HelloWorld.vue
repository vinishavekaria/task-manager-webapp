<template>
  <h1>{{ msg }}</h1>

  <div class="card">
    <task-list :tasks="tasks" @add-task="addTask" @remove-task="removeTask"/>
  </div>
</template>

<script>
import TaskList from './TaskList.vue';

export default {
  components: {
    TaskList
  },
  data() {
    return {
      msg: 'Task List',
      tasks: []  
    };
  },
  mounted() {
    this.fetchTasks(); 
  },
  methods: {
    // Fetch tasks from backend
    async fetchTasks() {
      const response = await fetch('http://localhost:8000/tasks/');
      const data = await response.json();
      this.tasks = data;  // Assign fetched tasks to tasks state
    },
    
    // Add new task
    async addTask() {
      const response = await fetch('http://localhost:8000/tasks/add/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ title: 'New Task', description: 'Description', due_date: '2024-12-31', completed: false })
      });
      const newTask = await response.json();
      this.tasks.push(newTask);  // Add new task to tasks array
    },

    // Remove task
    async removeTask(taskId) {
      await fetch(`http://localhost:8000/tasks/delete/${taskId}/`, {
        method: 'DELETE'
      });
      this.tasks = this.tasks.filter(task => task.id !== taskId);  
    }
  }
}
</script>

<style scoped>
/* Your styles */
ul {
  list-style-type: none;
}

li {
  margin: 10px 0;
}

button {
  margin-left: 10px;
  padding: 5px;
  cursor: pointer;
}
</style>
