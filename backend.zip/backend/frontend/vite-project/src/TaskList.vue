<template>
  <div class="task-container">
    <!-- tab for Tasks and Users -->
    <ul class="nav nav-tabs" id="myTab" role="tablist">
      <li class="nav-item" role="presentation">
        <a class="nav-link active" id="tasks-tab" data-bs-toggle="tab" href="#tasks" role="tab" aria-controls="tasks" aria-selected="true">Tasks</a>
      </li>
      <li class="nav-item" role="presentation">
        <a class="nav-link" id="users-tab" data-bs-toggle="tab" href="#users" role="tab" aria-controls="users" aria-selected="false">Users</a>
      </li>
    </ul>

    <!-- Tab content -->
    <div class="tab-content" id="myTabContent">
      <!-- Tasks Tab Content -->
      <div class="tab-pane fade show active" id="tasks" role="tabpanel" aria-labelledby="tasks-tab">
        <ul class="task-list">
          <!-- Loop through tasks and use TaskItem.vue for each task -->
          <TaskItem 
            v-for="task in tasks" 
            :key="task.id" 
            :task="task" 
            @edit-task="editTask" 
            @delete-task="deleteTask" 
          />
        </ul>

        <!-- Add task button -->
        <button @click="addTask" class="add-task-btn">Add new task</button>

        <!-- Error message -->
        <div v-if="errorMessage" class="error-message">
          <p>{{ errorMessage }}</p>
        </div>
      </div>

      <!-- Users tab -->
      <div class="tab-pane fade" id="users" role="tabpanel" aria-labelledby="users-tab">
        <h3>Users List</h3>
        <ul class="users-list">
          <!-- Loop through users and display them -->
          <li v-for="user in users" :key="user.id">
            <p>{{ user.username }} (Email: {{ user.email }})</p>
            <button @click="assignUserToTask(user)">Assign to Task</button>
          </li>
        </ul>
      </div>
    </div>

    <!-- Edit task  -->
    <div v-if="editingTask" class="edit-task-form">
      <h3>Edit Task</h3>
      <form @submit.prevent="updateTask">
        <input v-model="editingTask.title" placeholder="Title" required />
        <textarea v-model="editingTask.description" placeholder="Description" required></textarea>
        <input v-model="editingTask.due_date" type="date" required />
        <label>
          Completed:
          <input type="checkbox" v-model="editingTask.completed" />
        </label>
        <button type="submit">Update Task</button>
        <button @click="cancelEdit" type="button">Cancel</button>
      </form>
    </div>
  </div>
</template>

<script>
import TaskItem from './TaskItem.vue';  // Import TaskItem component

export default {
  components: {
    TaskItem,
  },
  data() {
    return {
      tasks: [],  
      users: [], 
      editingTask: null, 
      errorMessage: '', 
    };
  },
  methods: {
    async fetchTasks() {
      try {
        const response = await fetch('http://localhost:8000/tasks/');
        if (!response.ok) {
          throw new Error('Failed to fetch tasks');
        }
        const data = await response.json();
        this.tasks = data;
      } catch (error) {
        this.errorMessage = error.message;
        console.error('Error fetching tasks:', error);
      }
    },

    // Fetch users from the backend
    async fetchUsers() {
      try {
        const response = await fetch('http://localhost:8000/api/users/'); 
        if (!response.ok) {
          throw new Error('Failed to fetch users');
        }
        const data = await response.json();
        this.users = data;
      } catch (error) {
        this.errorMessage = error.message;
        console.error('Error fetching users:', error);
      }
    },

    // Add a new task
    async addTask() {
      try {
        const newTask = {
          title: 'New Task',
          description: 'Task description goes here',
          due_date: '2024-12-01',
          completed: false,
        };

        const response = await fetch('http://localhost:8000/tasks/add/', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(newTask),
        });

        if (!response.ok) {
          throw new Error('Failed to add task');
        }

        const task = await response.json();
        this.tasks.push(task);  
      } catch (error) {
        this.errorMessage = error.message;
        console.error('Error adding task:', error);
      }
    },

    // Delete a task
    async deleteTask(taskId) {
      try {
        const response = await fetch(`http://localhost:8000/tasks/delete/${taskId}/`, {
          method: 'DELETE',
        });

        if (!response.ok) {
          throw new Error('Failed to delete task');
        }

        this.tasks = this.tasks.filter(task => task.id !== taskId);  // Removes deleted task from the list
      } catch (error) {
        this.errorMessage = error.message;
        console.error('Error deleting task:', error);
      }
    },

   
    editTask(task) {
      this.editingTask = { ...task };
    },

    // Update the edited task
    async updateTask() {
      try {
        const response = await fetch(`http://localhost:8000/tasks/update/${this.editingTask.id}/`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(this.editingTask),
        });

        if (!response.ok) {
          throw new Error('Failed to update task');
        }

        const updatedTask = await response.json();

        // Update the task in the array
        const index = this.tasks.findIndex(task => task.id === updatedTask.id);
        if (index !== -1) {
          this.tasks.splice(index, 1, updatedTask); 
        }

        this.editingTask = null;  
      } catch (error) {
        this.errorMessage = error.message;
        console.error('Error updating task:', error);
      }
    },

    // Cancel the editing process and close the form
    cancelEdit() {
      this.editingTask = null; 
    },

    // Assign a user to a task
    async assignUserToTask(user) {
      try {
        const taskId = 1;

        const response = await fetch(`http://localhost:8000/tasks/${taskId}/assign/`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            user_id: user.id,  // Assign the user by ID
          }),
        });

        if (!response.ok) {
          throw new Error('Failed to assign user to task');
        }

        const result = await response.json();
        console.log('User assigned to task:', result);
      } catch (error) {
        this.errorMessage = error.message;
        console.error('Error assigning user to task:', error);
      }
    },
  },
  mounted() {
    this.fetchTasks(); 
    this.fetchUsers();   
  },
};
</script>

<style scoped>
/* Task container styling */
.task-container {
  font-family: Arial, sans-serif;
  padding: 20px;
  background-color: #f4f7f6;
}

/* Task list styling */
.task-list {
  list-style-type: none;
  padding: 0;
}

/* Task item styling */
.task-item {
  margin: 15px 0;
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  background-color: #ffffff;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.task-details {
  flex-grow: 1;
}

/* Task title and description styling */
.task-item h3 {
  margin: 0;
  font-size: 1.5em;
  color: #333;
}

.task-item p {
  margin: 5px 0;
  font-size: 1em;
  color: #666;
}

/* Buttons styling */
.delete-btn, .edit-btn {
  background-color: #ff5c8d;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  cursor: pointer;
}

.delete-btn:hover, .edit-btn:hover {
  background-color: #ff2d56;
}

.add-task-btn {
  margin-top: 20px;
  padding: 12px 25px;
  background-color: #42b883;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 1.2em;
}

.add-task-btn:hover {
  background-color: #388e3c;
}

/* Edit task form styling */
.edit-task-form {
  margin-top: 20px;
  padding: 15px;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.edit-task-form input, .edit-task-form textarea {
  width: 100%;
  margin: 10px 0;
  padding: 8px;
  border-radius: 5px;
  border: 1px solid #ddd;
}

.edit-task-form button {
  background-color: #42b883;
  color: white;
  border: none;
  padding: 10px 15px;
  border-radius: 5px;
  cursor: pointer;
}

.edit-task-form button:hover {
  background-color: #388e3c;
}

/* Error message styling */
.error-message {
  color: red;
  margin-top: 10px;
}

/* Users list and assigned task user styling */
.users-list p, .assign-to-task p {
  color: black; /* Change text color to black */
}

/* Specific styling for users' names and emails if needed */
.users-list li, .assign-to-task li {
  color: black; /* Ensure each user item has black text */
}

/* Optionally, for individual user items */
.users-list span, .assign-to-task span {
  color: black; /* Apply black color to name and email */
}

</style>
