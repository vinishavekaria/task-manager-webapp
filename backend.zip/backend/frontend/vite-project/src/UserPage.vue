<template>
  <div>
    <h2>User List</h2>
    <UserForm @user-added="refreshUserList" />
    <ul>
      <li v-for="user in users" :key="user.id">{{ user.username }} - {{ user.email }}</li>
    </ul>
  </div>
</template>

<script>
import UserForm from './UserForm.vue'; // Import the UserForm component

export default {
  components: {
    UserForm
  },
  data() {
    return {
      users: []  // Array to hold the list of users
    };
  },
  methods: {
    // Fetch the list of users
    async fetchUsers() {
      const response = await fetch('http://localhost:8000/api/users/');
      const data = await response.json();
      this.users = data;
    },
    // Refresh the user list after a new user is added
    refreshUserList(newUser) {
      this.users.push(newUser);  // Add the new user to the list
    }
  },
  mounted() {
    this.fetchUsers();  // Fetch the list of users when the page loads
  }
};
</script>
