<template>
  <li class="task-item">
    <div class="task-details">
      <h3>{{ task.title }}</h3>
      <p>{{ task.description }}</p>
      <p>Due Date: {{ task.due_date }}</p>
      <p>Status: <strong>{{ task.completed ? 'Completed' : 'Pending' }}</strong></p>
    </div>

    <!-- Action buttons for task -->
    <button @click="handleDelete" class="delete-btn">Delete</button>
    <button @click="handleEdit" class="edit-btn">Edit</button>
  </li>
</template>

<script>
export default {
  props: {
    task: Object,  // task object passed from parent
  },
  methods: {
    // Delete task, emits event to the parent to delete the task
    handleDelete() {
      this.$emit('delete-task', this.task.id);
    },

    // Edit task, emitsevent to the parent to start editing
    handleEdit() {
      this.$emit('edit-task', this.task);
    },
  },
};
</script>

<style scoped>
.task-item {
  margin: 15px 0;
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  background-color: #ffffff;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.task-details {
  flex-grow: 1;
}

.task-item h3 {
  margin: 0;
  font-size: 1.5em;
  color: #333;
}

.task-item p {
  margin: 5px 0;
  font-size: 1em;
  color: #666;
}

.delete-btn, .edit-btn {
  background-color: #ff5c8d;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  cursor: pointer;
}

.delete-btn:hover, .edit-btn:hover {
  background-color: #ff2d56;
}
</style>
