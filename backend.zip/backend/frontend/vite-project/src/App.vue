<template>
  <div class="app">
    <header class="app-header">
      <h1>Task List</h1>
    </header>
    <TaskList /> <!-- display the tasks -->
  </div>
</template>

<script setup>
import TaskList from './TaskList.vue'
</script>

<style scoped>
.app {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: #f4f7f6;
}

.app-header {
  background-color: #3b6978;
  color: white;
  padding: 20px;
  text-align: center;
  width: 100%;
}

.app-header h1 {
  margin: 0;
  font-size: 2.5em;
}

.task-list {
  margin-top: 20px;
  width: 80%;
  max-width: 800px;
  padding: 20px;
  background-color: #ffffff;
  border-radius: 10px;
  box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
}
</style>
